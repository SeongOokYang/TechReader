let body = document.getElementsByTagName("body")[0];

$(body).on("click", getUserSelectText);

function getUserSelectText() {
    let selectObj = window.getSelection();
    let selectText = selectObj.toString();
    console.log(selectText);
}