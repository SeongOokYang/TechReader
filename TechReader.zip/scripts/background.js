chrome.tabs.addEventListener('create', getReady);

function getReady(event) {
    chrome.scripting.executeScript({
        target:{tabId : event.id},
        files:["content_script.js"]
    });
}